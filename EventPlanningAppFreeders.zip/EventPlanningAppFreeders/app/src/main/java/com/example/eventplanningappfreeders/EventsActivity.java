package com.example.eventplanningappfreeders;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

// Shows events and lets the user create, update, and delete them
public class EventsActivity extends AppCompatActivity {

    private EditText editEventTitle;
    private EditText editEventDate;
    private EditText editEventTime;
    private EditText editEventDetails;
    private Button buttonAddUpdateEvent;
    private ListView listViewEvents;

    private DatabaseHelper dbHelper;
    private ArrayAdapter<String> eventsAdapter;
    private ArrayList<String> eventDisplayList = new ArrayList<>();
    private ArrayList<Integer> eventIdList = new ArrayList<>();

    // If -1, we are adding a new event. Otherwise we are editing an existing one.
    private int selectedEventId = -1;

    // Code used when requesting SMS permission
    private static final int SMS_PERMISSION_CODE = 1001;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_events);

        dbHelper = new DatabaseHelper(this);

        editEventTitle = findViewById(R.id.editEventTitle);
        editEventDate = findViewById(R.id.editEventDate);
        editEventTime = findViewById(R.id.editEventTime);
        editEventDetails = findViewById(R.id.editEventDetails);
        buttonAddUpdateEvent = findViewById(R.id.buttonAddUpdateEvent);
        listViewEvents = findViewById(R.id.listViewEvents);

        // Set up ListView adapter
        eventsAdapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_list_item_1,
                eventDisplayList
        );
        listViewEvents.setAdapter(eventsAdapter);

        // Load existing events from the database
        loadEvents();

        // Add or update event when button is pressed
        buttonAddUpdateEvent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveEvent();
            }
        });

        // Tap an item to start editing it
        listViewEvents.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                startEditingEvent(position);
            }
        });

        // Long-press an item to delete it
        listViewEvents.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                deleteEvent(position);
                return true;
            }
        });
    }

    // Load events from the database into the ListView
    private void loadEvents() {
        eventDisplayList.clear();
        eventIdList.clear();

        Cursor cursor = dbHelper.getAllEvents();
        if (cursor != null && cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.COL_EVENT_ID));
                String title = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COL_EVENT_TITLE));
                String date = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COL_EVENT_DATE));
                String time = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COL_EVENT_TIME));

                String display = title + "  -  " + date + "  " + time;
                eventDisplayList.add(display);
                eventIdList.add(id);
            } while (cursor.moveToNext());
            cursor.close();
        }

        eventsAdapter.notifyDataSetChanged();
    }

    // Add a new event or update an existing one
    private void saveEvent() {
        String title = editEventTitle.getText().toString().trim();
        String date = editEventDate.getText().toString().trim();
        String time = editEventTime.getText().toString().trim();
        String details = editEventDetails.getText().toString().trim();

        if (title.isEmpty()) {
            Toast.makeText(this, "Please enter an event title.", Toast.LENGTH_SHORT).show();
            return;
        }

        if (selectedEventId == -1) {
            // Create
            long result = dbHelper.addEvent(title, date, time, details);
            if (result != -1) {
                Toast.makeText(this, "Event added.", Toast.LENGTH_SHORT).show();

                // Build a simple SMS reminder message for the new event
                String message = "Reminder: You added a new event: " + title +
                        " on " + date + " at " + time;
                sendSmsReminder(message);

            } else {
                Toast.makeText(this, "Error adding event.", Toast.LENGTH_SHORT).show();
            }
        } else {
            // Update
            boolean success = dbHelper.updateEvent(selectedEventId, title, date, time, details);
            if (success) {
                Toast.makeText(this, "Event updated.", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Error updating event.", Toast.LENGTH_SHORT).show();
            }
        }

        clearForm();
        loadEvents();
    }

    // Fill the form with the selected event's data for editing
    private void startEditingEvent(int position) {
        if (position < 0 || position >= eventIdList.size()) return;

        int eventId = eventIdList.get(position);
        Cursor cursor = dbHelper.getEventById(eventId);

        if (cursor != null && cursor.moveToFirst()) {
            selectedEventId = eventId;

            String title = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COL_EVENT_TITLE));
            String date = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COL_EVENT_DATE));
            String time = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COL_EVENT_TIME));
            String details = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COL_EVENT_DETAILS));

            editEventTitle.setText(title);
            editEventDate.setText(date);
            editEventTime.setText(time);
            editEventDetails.setText(details);

            buttonAddUpdateEvent.setText("Update Event");

            cursor.close();
        }
    }

    // Delete an event that was long-pressed
    private void deleteEvent(int position) {
        if (position < 0 || position >= eventIdList.size()) return;

        int eventId = eventIdList.get(position);
        boolean success = dbHelper.deleteEvent(eventId);

        if (success) {
            Toast.makeText(this, "Event deleted.", Toast.LENGTH_SHORT).show();
            loadEvents();
        } else {
            Toast.makeText(this, "Error deleting event.", Toast.LENGTH_SHORT).show();
        }
    }

    // Reset the form back to "add" mode
    private void clearForm() {
        selectedEventId = -1;
        editEventTitle.setText("");
        editEventDate.setText("");
        editEventTime.setText("");
        editEventDetails.setText("");
        buttonAddUpdateEvent.setText("Add Event");
    }

    // Send SMS reminder for an event
    private void sendSmsReminder(String message) {
        // Check SMS permission
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {

            ActivityCompat.requestPermissions(
                    this,
                    new String[]{Manifest.permission.SEND_SMS},
                    SMS_PERMISSION_CODE
            );
            Toast.makeText(this, "SMS permission required to send reminders.", Toast.LENGTH_SHORT).show();
            return;
        }

        // For demo purposes, use a placeholder phone number.
        // In a real app, you would let the user configure this.
        String phoneNumber = "5551234567";

        try {
            SmsManager sms = SmsManager.getDefault();
            sms.sendTextMessage(phoneNumber, null, message, null, null);
            Toast.makeText(this, "Reminder sent via SMS.", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "Failed to send SMS.", Toast.LENGTH_SHORT).show();
        }
    }

    // Handle the result of the SMS permission request
    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == SMS_PERMISSION_CODE) {
            if (grantResults.length > 0 &&
                    grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "SMS permission granted. You can now send reminders.", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "SMS permission denied. App will continue without SMS alerts.", Toast.LENGTH_LONG).show();
            }
        }
    }
}
