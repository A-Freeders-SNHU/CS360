package com.example.eventplanningappfreeders;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

// Handles SMS permission and sending event notifications via SMS
public class SmsSettingsActivity extends AppCompatActivity {

    private static final int REQUEST_SMS_PERMISSION = 100;

    private EditText editPhoneNumber;
    private Button buttonRequestSmsPermission;
    private Button buttonSendTestSms;
    private TextView textSmsStatus;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms);

        editPhoneNumber = findViewById(R.id.editPhoneNumber);
        buttonRequestSmsPermission = findViewById(R.id.buttonRequestSmsPermission);
        buttonSendTestSms = findViewById(R.id.buttonSendTestSms);
        textSmsStatus = findViewById(R.id.textSmsStatus);

        // Update the status text based on current permission state
        updateSmsStatusText();

        buttonRequestSmsPermission.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                requestSmsPermission();
            }
        });

        buttonSendTestSms.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendTestSms();
            }
        });
    }

    // Check whether SEND_SMS permission is granted
    private boolean hasSmsPermission() {
        int result = ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.SEND_SMS
        );
        return result == PackageManager.PERMISSION_GRANTED;
    }

    // Ask the user for SMS permission at runtime
    private void requestSmsPermission() {
        if (hasSmsPermission()) {
            Toast.makeText(this, "SMS permission already granted.", Toast.LENGTH_SHORT).show();
            updateSmsStatusText();
            return;
        }

        ActivityCompat.requestPermissions(
                this,
                new String[]{Manifest.permission.SEND_SMS},
                REQUEST_SMS_PERMISSION
        );
    }

    // Called when the user responds to the permission request
    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == REQUEST_SMS_PERMISSION) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "SMS permission granted.", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "SMS permission denied. App will work without SMS alerts.", Toast.LENGTH_LONG).show();
            }
            updateSmsStatusText();
        }
    }

    // Update the status label to reflect current permission state
    private void updateSmsStatusText() {
        if (hasSmsPermission()) {
            textSmsStatus.setText("SMS permission: GRANTED");
        } else {
            textSmsStatus.setText("SMS permission: NOT GRANTED");
        }
    }

    // Send a simple test SMS reminder if permission is granted
    private void sendTestSms() {
        if (!hasSmsPermission()) {
            Toast.makeText(this, "Cannot send SMS. Please grant permission first.", Toast.LENGTH_SHORT).show();
            updateSmsStatusText();
            return;
        }

        String phoneNumber = editPhoneNumber.getText().toString().trim();

        if (phoneNumber.isEmpty()) {
            Toast.makeText(this, "Please enter a phone number.", Toast.LENGTH_SHORT).show();
            return;
        }

        String message = "Reminder: You have an upcoming event in your Event Planner app.";

        try {
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(phoneNumber, null, message, null, null);
            Toast.makeText(this, "Test SMS sent.", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "Error sending SMS: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }
}
